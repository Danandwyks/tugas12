<div class="pull-right hidden-xs">
    <b></b>
</div>
<strong>hasilkarya &copy; <?php echo date('Y'); ?> <a target='_BLANK' href="https://members.phpmu.com">- danan,jefri,ilham</a>.</strong> All rights reserved.