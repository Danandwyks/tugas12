<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>

<marquee><center><h1>KONSULTASI PEMBIMBING AKADEMIK</h1></center></marquee>
<form>
<table align="center">
  <tr>
      <td><strong>Nama Pembimbing Akademik</strong></td>
      <td><strong>:</strong></td>
      <td><input type="" name="nopembimbing"></td>
  </tr>
</table>
<table align="center" style="border: 10%"> 
  <tr>
      <td><strong>Kotak Pesan</strong></td>
      <td><strong>:</strong></td>
      <td><textarea  cols="100" rows="10" name="pesan"></textarea></td>
  </tr><br/>
</table>
</form>
<input type="submit" name="kirim" value="simpan">
<div class="box-body">
  <table id="example1" class="table table-bordered table-striped">
   
                    </table>
                  </div>
</body>
</html>
 <?php
    if(isset($_POST['submit'])){
        $nopembimbing = $_POST['nopembimbing'];
        $pesan = $_POST['pesan'];
        mysql_query("INSERT INTO mahasiswa VALUES('$nopembimbing','$pesan')");
  }
              ?>