<?php 
if ($_GET[act]==''){ 
cek_session_siswa();
if (isset($_GET[lihat])){
                      $tampil = mysql_query("SELECT * FROM logkondite as a 
                                            JOIN mahasiswa as b ON a.nama=b.nama
                                                 where a.nim=b.nim ");
                    
                    }else{
                      $tampil = mysql_query("SELECT *  FROM lohkondite  a 
                                            JOIN mahasiswa  b ON a.nama=b.nama
                                              
                                                  ");
                    }
                    $no = 1;
                    while($r=mysql_fetch_array($tampil)){
                    echo "<tr><td>$no</td>
                              <td>$r[jenispoin]</td>
							  <td>$r[poin]</td>
                              <td>$r[keterangan]</td>
                              <td>$r[tahun]</td>
  
                       
                              <td><a class='btn btn-success btn-xs' title='Lihat Data' ><span class='glyphicon glyphicon-list'></span> Kompetensi</a></td>
                          </tr>";
                      $no++;
                      }
?>
                  <?php
    if(isset($_POST['submit'])){
        $nim = $_POST['nim'];
        $nama = $_POST['nama'];
        $jenispoin = $_POST['jenispoin'];
        $poin = $_POST['poin'];
        $keterangan = $_POST['keterangan'];
        $tahunakademik = $_POST['tahunakademik'];
        $cek = mysqli_query($koneksi, "SELECT * FROM db_akd_072016 WHERE nim='$nim'") or die(mysqli_error($koneksi));
    if(mysqli_num_rows($cek) == 0){
        $sql = mysqli_query($koneksi, "INSERT INTO db_akd_072016(nim, nama, jenispoin, poin, keterangan, tahunakademik) VALUES('$nim', '$nama', '$jenispoin', '$poin', '$keterangan', '$tahunakademik')") or
    die(mysqli_error($koneksi));
    if($sql){
        echo '<script>alert("Berhasil menambahkan data.");
        document.location="tambah.php";</script>';
    }else{
        echo '<div class="alert alert-warning">Gagal melakukan proses tambah data.</div>';
    }
    }else{
        echo '<div class="alert alert-warning">Gagal, NIM sudah terdaftar.</div>';
    }
  }
              ?>



                  <form action="tambah.php" method="post">
<div class="form-group row">
<label class="col-sm-2 col-form-label">NIM</label>
<div class="col-sm-10">
<input type="text" name="nim" class="form-control"
size="4" required>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Nama Mahasiswa</label>
<div class="col-sm-10">
<input type="text" name="nama" class="form-control"
required>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Jenis Poin</label>
<div class="col-sm-10">
<input type="text" name="nim" class="form-control"
size="4" required>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Poin</label>
<div class="col-sm-10">
<input type="text" name="nim" class="form-control"
size="4" required>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Keterangan</label>
<div class="col-sm-10">
<input type="text" name="nim" class="form-control"
size="4" required>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">Tahun Akademik</label>
<div class="col-sm-10">
<input type="text" name="nim" class="form-control"
size="4" required>
</div>
</div>

<div class="form-group row">

<div class="col-sm-10">
<div class="form-check">
</div>
</div>
</div>

<div class="form-group row">
<label class="col-sm-2 col-form-label">&nbsp;</label>
<div class="col-sm-10">
<input type="submit" name="submit" class="btn btnprimary"
value="SIMPAN">
</div>
</div>
</form>


                </div><!-- /.box-body -->
                </div>
            </div>
                                
<?php
}elseif($_GET[act]=='detailsiswa'){
cek_session_siswa();
?><div class="col-xs-12">  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title"><?php if (isset($_GET[tahun])){ echo "Daftar Dosen Pengajar"; }else{ echo "Poin siswa pada Tahun ".date('Y'); } ?></h3>
                  <form style='margin-right:5px; margin-top:0px' class='pull-right' action='' method='GET'>
                   
                  </form>  

                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th style='width:20px'>No</th>
                        <th>Jenis Poin</th>
                        <th>Poin</th>
                        <th>Keterangan</th>
                        <th>Tahun Akademik</th>
                  
                      </tr>
                    </thead>
                    <tbody>

                    
                    <?php
if (isset($_GET[tahun])){
                      $tampil = mysql_query("SELECT * FROM logkondite as a 
                                            JOIN mahasiswa as b ON a.nama=b.nama
                                                 where a.nim=b.nim ");
                    
                    }else{
                      $tampil = mysql_query("SELECT *  FROM logkondite  a 
                                            JOIN mahasiswa  b ON a.nama=b.nama
                                              
                                                  ");
                    }
                    $no = 1;
                    while($r=mysql_fetch_array($tampil)){
                    echo "<tr><td>$no</td>
                              <td>$r[jenispoin]</td>
							  <td>$r[poin]</td>
                              <td>$r[keterangan]</td>
                              <td>$r[tahun]</td>
  
                       
                              
                          </tr>";
                      $no++;
                      }
                  ?>

                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                </div>
            </div>
                  <?php
                    /*if (isset($_GET[tahun])){
                      $tampil = mysql_query("SELECT a.*, e.nama_kelas, b.namamatapelajaran, b.kode_pelajaran, b.kode_kurikulum, c.nama_guru, d.nama_ruangan FROM rb_jadwal_pelajaran a 
                                            JOIN rb_mata_pelajaran b ON a.kode_pelajaran=b.kode_pelajaran
                                              JOIN rb_guru c ON a.nip=c.nip 
                                                JOIN rb_ruangan d ON a.kode_ruangan=d.kode_ruangan
                                                  JOIN rb_kelas e ON a.kode_kelas=e.kode_kelas 
                                                  where a.kode_kelas='$_SESSION[kode_kelas]' 
                                                    AND a.id_tahun_akademik='$_GET[tahun]'
                                                      AND b.kode_kurikulum='$kurikulum[kode_kurikulum]' 
                                                        ORDER BY a.hari DESC");
                    
                    }else{
                      $tampil = mysql_query("SELECT a.*, e.nama_kelas, b.namamatapelajaran, b.kode_pelajaran, b.kode_kurikulum, c.nama_guru, d.nama_ruangan FROM rb_jadwal_pelajaran a 
                                            JOIN rb_mata_pelajaran b ON a.kode_pelajaran=b.kode_pelajaran
                                              JOIN rb_guru c ON a.nip=c.nip 
                                                JOIN rb_ruangan d ON a.kode_ruangan=d.kode_ruangan
                                                JOIN rb_kelas e ON a.kode_kelas=e.kode_kelas 
                                                  where a.kode_kelas='$_SESSION[kode_kelas]' 
                                                    AND b.kode_kurikulum='$kurikulum[kode_kurikulum]'
                                                     AND a.id_tahun_akademik LIKE '".date('Y')."%' ORDER BY a.hari DESC");
                    }
                    $no = 1;
                    while($r=mysql_fetch_array($tampil)){
                    $total = mysql_num_rows(mysql_query("SELECT * FROM rb_quiz_ujian where kodejdwl='$r[kodejdwl]'"));
                    echo "<tr><td>$no</td>
                              <td>$r[kode_pelajaran]</td>
                              <td>$r[namamatapelajaran]</td>
                              <td>$r[nama_kelas]</td>
                              <td>$r[nama_guru]</td>
                              <td style='color:red'>$total Record</td>
                              <td><a class='btn btn-success btn-xs' title='List QUiz dan Ujian' href='index.php?view=soal&act=listsoalsiswa&jdwl=$r[kodejdwl]&id=$r[kode_kelas]&kd=$r[kode_pelajaran]'><span class='glyphicon glyphicon-th'></span> Tampilkan</a></td>
                          </tr>";
                      $no++;
                      }*/
                      ?>
                                
<?php         
}elseif($_GET[act]=='listsoalsiswa'){
cek_session_siswa();
    $d = mysql_fetch_array(mysql_query("SELECT * FROM rb_kelas where kode_kelas='$_GET[id]'"));
    $m = mysql_fetch_array(mysql_query("SELECT * FROM rb_mata_pelajaran where kode_pelajaran='$_GET[kd]'"));
    echo "<div class='col-md-12'>
              <div class='box box-info'>
                <div class='box-header with-border'>
                  <h3 class='box-title'>Daftar Ujian dan Quiz Online</b></h3>
                </div>
              <div class='box-body'>

              <div class='col-md-12'>
              <table class='table table-condensed table-hover'>
                  <tbody>
                    <input type='hidden' name='id' value='$s[kodekelas]'>
                    <tr><th width='120px' scope='row'>Kode Kelas</th> <td>$d[kode_kelas]</td></tr>
                    <tr><th scope='row'>Nama Kelas</th>               <td>$d[nama_kelas]</td></tr>
                    <tr><th scope='row'>Mata Pelajaran</th>           <td>$m[namamatapelajaran]</td></tr>
                  </tbody>
              </table>
              </div>

                <div class='col-md-12'>
                  <table id='example1' class='table table-condensed table-bordered table-striped'>
                      <thead>
                      <tr>
                        <th style='width:40px'>No</th>
                        <th>Kategori</th>
                        <th>Keterangan</th>
                        <th>Batas Waktu</th>
                        <th style='width:80px'>Action</th>
                      </tr>
                    </thead>
                    <tbody>";
                    
                    $no = 1;
                    $tampil = mysql_query("SELECT * FROM rb_quiz_ujian a JOIN rb_kategori_quiz_ujian b ON a.id_kategori_quiz_ujian=b.id_kategori_quiz_ujian where a.kodejdwl='$_GET[jdwl]' ORDER BY a.id_quiz_ujian");
                    while($r=mysql_fetch_array($tampil)){
                    echo "<tr>
                            <td>$no</td>
                            <td style='color:red'>$r[kategori_quiz_ujian]</td>
                            <td>$r[keterangan]</td>
                            <td>$r[batas_waktu] WIB</td>";
                            $sekarangwaktu = date("YmdHis");
                            $bataswaktu1 = str_replace('-','',$r[batas_waktu]);
                            $bataswaktu2 = str_replace(':','',$bataswaktu1);
                            $bataswaktu3 = str_replace(' ','',$bataswaktu2);
                            if ($sekarangwaktu > $bataswaktu3){
                            //  echo "<td><a style='width:100px' class='btn btn-danger btn-xs' title='Lihat Soal $sekarangwaktu - $bataswaktu3' href=''><span class='glyphicon glyphicon-search'></span> Waktu Habis</a></td>";
                            }else{
                             // echo "<td><a style='width:100px' class='btn btn-primary btn-xs' title='Lihat Soal' href='index.php?view=soal&act=jawabsemuasoal&jdwl=$_GET[jdwl]&idsoal=$r[id_quiz_ujian]&id=$_GET[id]&kd=$_GET[kd]'><span class='glyphicon glyphicon-search'></span> Jawab Soal</a></td>";
                            }
                          echo "</tr>";
                      $no++;
                      }

                    echo "</tbody>
                  </table>
                </div>
              </div>
              </form>
            </div>";

}elseif($_GET[act]=='jawabsemuasoal'){
cek_session_siswa();
    $jml = mysql_fetch_array(mysql_query("SELECT count(*) as jmlp FROM `rb_pertanyaan_objektif` where id_quiz_ujian='$_GET[idsoal]'"));
    if (isset($_POST['simpanobjektif'])){
       $n = $jml[jmlp];
       for ($i=0; $i<=$n; $i++){
         if (isset($_POST['a'.$i])){
           $jawab = $_POST['a'.$i];
           $pertanyaan = $_POST['b'.$i];
            $cek = mysql_fetch_array(mysql_query("SELECT count(*) as tot FROM rb_jawaban_objektif where nisn='$iden[nisn]' AND id_pertanyaan_objektif='$pertanyaan'"));
            if ($cek[tot] >= 1){
              mysql_query("UPDATE rb_jawaban_objektif SET jawaban='$jawab' where id_pertanyaan_objektif='$pertanyaan' AND nisn='$iden[nisn]'");
            }else{
              $waktuobjektif = date("Y-m-d H:i:s");
              mysql_query("INSERT INTO rb_jawaban_objektif (nisn, id_pertanyaan_objektif, jawaban, waktu_objektif) VALUES('$iden[nisn]','$pertanyaan','$jawab','$waktuobjektif')");
          }
         }
       }
       //echo "<script>document.location='index.php?view=soal&act=jawabsemuasoal&jdwl=$_GET[jdwl]&idsoal=$_GET[idsoal]&id=$_GET[id]&kd=$_GET[kd]';</script>";
    }

      $so = mysql_fetch_array(mysql_query("SELECT * FROM rb_quiz_ujian a 
                        JOIN rb_kategori_quiz_ujian b ON a.id_kategori_quiz_ujian=b.id_kategori_quiz_ujian 
                          JOIN rb_jadwal_pelajaran c ON a.kodejdwl=c.kodejdwl 
                            JOIN rb_kelas d ON c.kode_kelas=d.kode_kelas where a.id_quiz_ujian='$_GET[idsoal]'"));

            echo "<div class='col-xs-12'>  
              <div class='box'>
                <div class='box-header'>
                  <h3 class='box-title'>Jawab Soal Essai '<span class='text-info'>$so[kategori_quiz_ujian]</span>' 
                    <br><small>$so[nama_kelas] - $so[keterangan]</small></h3>
                </div>
                <div class='box-body'>
                  <table class='table table-condensed table-bordered table-striped'>
                        <tr bgcolor=#cecece>
                          <th style='width:40px'>No</th>
                          <th>Pertanyaan Essai</th>
                          <th>Point</th>
                        </tr>";
                    $essai = mysql_query("SELECT * FROM `rb_pertanyaan_essai` where id_quiz_ujian='$_GET[idsoal]' ORDER BY id_pertanyaan_essai DESC");
                    $no = 1;
                    while ($k = mysql_fetch_array($essai)){
                       $je = mysql_fetch_array(mysql_query("SELECT * FROM rb_jawaban_essai where id_pertanyaan_essai='$k[id_pertanyaan_essai]' AND nisn='$iden[nisn]'"));
                        echo "<tr>
                            <td>$no</td>
                            <td>$k[pertanyaan_essai] <br>
                                <b>Jabawan</b> : <pre>$je[jawaban_essai]</pre></td>
                            
                            </tr>";
                      $no++;
                    } 
              echo "</table>
                </div>
              </div>

              <div class='box'>
                <div class='box-header'>
                  <h3 class='box-title'>Soal Objektif '<span class='text-info'>$so[kategori_quiz_ujian]</span>' 
                  <br><small>$so[nama_kelas] - $so[keterangan]</small></h3>
                </div>
                <div class='box-body'>
                <form action='' method='POST'>
                  <table class='table table-condensed table-bordered'>
                    <tr>
                      <th style='width:40px'>No</th>
                      <th>Pertanyaan Objektif</th>
                    </tr>";
                    $objektif = mysql_query("SELECT * FROM `rb_pertanyaan_objektif` where id_quiz_ujian='$_GET[idsoal]' ORDER BY id_pertanyaan_objektif DESC");
                    $noo = 1;
                    while ($ko = mysql_fetch_array($objektif)){
                      $ce = mysql_fetch_array(mysql_query("SELECT * FROM rb_jawaban_objektif where id_pertanyaan_objektif='$ko[id_pertanyaan_objektif]' AND nisn='$iden[nisn]'"));
                        echo "<tr>
                            <td>$noo</td>
                            <td>$ko[pertanyaan_objektif] <br>
                                <input type='hidden' value='$ko[id_pertanyaan_objektif]' name='b".$noo."'>";
                               if ($ce[jawaban]=='a'){
                                if (trim($ko[jawab_a])!=''){ echo "<input type='radio' name='a".$noo."' value='a' checked> a. $ko[jawab_a] <br>"; }
                               }else{
                                if (trim($ko[jawab_a])!=''){ echo "<input type='radio' name='a".$noo."' value='a'> a. $ko[jawab_a] <br>"; }
                               }

                               if ($ce[jawaban]=='b'){
                                if (trim($ko[jawab_b])!=''){ echo "<input type='radio' name='a".$noo."' value='b' checked> b. $ko[jawab_b] <br>"; }
                               }else{
                                if (trim($ko[jawab_b])!=''){ echo "<input type='radio' name='a".$noo."' value='b'> b. $ko[jawab_b] <br>"; }
                               }

                               if ($ce[jawaban]=='c'){
                                if (trim($ko[jawab_c])!=''){ echo "<input type='radio' name='a".$noo."' value='c' checked> c. $ko[jawab_c] <br>"; }
                               }else{
                                if (trim($ko[jawab_c])!=''){ echo "<input type='radio' name='a".$noo."' value='c'> c. $ko[jawab_c] <br>"; }
                               }

                               if ($ce[jawaban]=='d'){
                                if (trim($ko[jawab_d])!=''){ echo "<input type='radio' name='a".$noo."' value='d' checked> d. $ko[jawab_d] <br>"; }
                               }else{
                                if (trim($ko[jawab_d])!=''){ echo "<input type='radio' name='a".$noo."' value='d'> d. $ko[jawab_d] <br>"; }
                               }

                               if ($ce[jawaban]=='e'){
                                if (trim($ko[jawab_e])!=''){ echo "<input type='radio' name='a".$noo."' value='e' checked> e. $ko[jawab_e]"; }
                               }else{
                                if (trim($ko[jawab_e])!=''){ echo "<input type='radio' name='a".$noo."' value='e'> e. $ko[jawab_e]"; }
                               }
                            echo "</td>
                            </tr>";
                      $noo++;
                    } 
              echo "</table>
              <div class='box-footer'>
                    <button type='submit' name='simpanobjektif' class='btn btn-info btn-sm pull-right'>Simpan Jawaban</button>
              </div>
              </form>
                </div>
              </div>
            </div>";
}elseif($_GET[act]=='jawabsoalessai'){
cek_session_siswa();
    if (isset($_POST[simpan])){
      $cek = mysql_fetch_array(mysql_query("SELECT count(*) as total FROM rb_jawaban_essai where nisn='$iden[nisn]' AND id_pertanyaan_essai='$_GET[idp]'"));
      if ($cek[total]>=1){
          mysql_query("UPDATE rb_jawaban_essai SET jawaban_essai = '$_POST[a]' where nisn='$iden[nisn]' AND id_pertanyaan_essai='$_GET[idp]'");
      }else{
          $waktujawab = date("Y-m-d H:i:s");
          mysql_query("INSERT INTO rb_jawaban_essai VALUES('','$iden[nisn]','$_GET[idp]','$_POST[a]','$waktujawab')");
      } 
      //echo "<script>document.location='index.php?view=soal&act=jawabsemuasoal&jdwl=$_GET[jdwl]&idsoal=$_GET[idsoal]&id=$_GET[id]&kd=$_GET[kd]';</script>";
    }

    $n = mysql_fetch_array(mysql_query("SELECT * FROM rb_jawaban_essai where nisn='$iden[nisn]' AND id_pertanyaan_essai='$_GET[idp]'"));
    echo "<form method='POST' class='form-horizontal' action='' enctype='multipart/form-data'>
            <div class='col-md-12'>
              <div class='box box-info'>
                <div class='box-header with-border'>
                  <h3 class='box-title'>Jawab Soal Essai</h3>
                </div>
              <div class='box-body'>
              
                  <table class='table table-condensed table-bordered'>
                  <tbody>
                    <tr><th width=120px scope='row'>Jawaban</th>           <td><textarea rows='4' class='form-control' name='a'>$n[jawaban_essai]</textarea></td></tr>
                  </tbody>
                  </table>
              </div>

              <div class='box-footer'>
                    <button type='submit' name='simpan' class='btn btn-info'>Submit</button>
                                  </div>
            </div>
          </form>";
}
?>