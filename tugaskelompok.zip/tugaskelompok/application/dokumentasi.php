<?php if ($_GET[act]==''){ ?> 
            <div class="col-xs-12">  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Dokumentasi Administrator</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div style='padding:10px;'>
                    	<embed src="dokumentasi/administrator.pdf" quality="high" name="fb" allowScriptAccess="always" allowFullScreen="true" pluginpage="http://www.adobe.com/go/getreader" type="application/pdf" width="100%" height="1100"></embed>
                    </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
<?php 
}
?>