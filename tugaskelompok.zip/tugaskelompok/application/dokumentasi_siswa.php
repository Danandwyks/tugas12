<?php if ($_GET[act]==''){ ?> 
            <div class="col-xs-12">  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Dokumentasi Siswa</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div style='padding:90px;'><center>Video Dokumentasi Sistem Informasi Akademik Sekolah ini masih dalam proses !<br>
                                          Insyaallah akan kita selesaikan secepatnya.</center></div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
<?php 
}
?>