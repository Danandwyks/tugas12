<?php 
if ($_GET[act]==''){ 
    if (isset($_POST['submit'])){
         $a1 = $_GET['a1'];
           $a2 = $_GET['a2'];
           $a3 = $_GET['a3'];
		    $a4 = $_GET['a4'];
           $a5 = $_GET['a5'];
           $a6 = $_GET['a6'];
		    $a7 = $_GET['a7'];
           $a8 = $_GET['a8'];
           $a9 = $_GET['a9'];
		    $a10 = $_GET['a10'];
           $a11 = $_GET['a11'];
           $b1 = $_GET['b1'];
		      $b2 = $_GET['b2'];
			     $b3 = $_GET['b3'];
				    $b4 = $_GET['b4'];
					   $b5 = $_GET['b5'];
					      $b6 = $_GET['b6'];
						     $c1 = $_GET['c1'];
							    $c2 = $_GET['c2'];
								   $c3 = $_GET['c3'];
								      $c4 = $_GET['c4'];
									     $d1 = $_GET['d1'];
										    $d2 = $_GET['d2'];
											   $d3 = $_GET['d3'];
											      $d4 = $_GET['d4'];
												  $d5 = $_GET['d5'];
												  $d6 = $_GET['d6'];
												  $id=$_GET['id'];
            $cek = mysql_fetch_array(mysql_query("SELECT id as tot FROM evaluasidosen where id='$_SESSION[id]'"));
            if ($cek[tot] >= 1){
              mysql_query("UPDATE evaluasidosen SET a1='$a1' where id='$_SESSION[id]'");
           // }else{
		   
             // mysql_query("INSERT INTO evaluasidosen('a1','a2','a3','a4','a5','a6','a7','a8','a9','a10',a'11','b1','b2','b3','b4','b5','b6','b7','b8','b9','c1','c2','c3','c4','d1','d2','d3','d4','d5','d6' )  VALUES('$_GET[a1]','$a2','$a3','$a4','$a5','$a6','$a7','$a8','$a9','$a10','$a11','$b1','$b2','$b3','$b4','$b5','$b6','$b7','$b8','$b9','$c1','$c2','$c3','$c4','$d1','$d2','$d3','$d4','$d5','$d6')");

         }
       
       echo "<script>window.alert('Sukses Simpan Jawaban Penilaian Diri...');
                window.location='index.php?view=penilaiandirisiswa'</script>";
    }
?> 
            <div class="col-xs-12">  
              <div class="box">
              <form action='' method='POST'>
                <div class="box-header">
                  <h3 class="box-title">Data Pertanyan Penilaian Diri </h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example3" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th style='width:20px'>No</th>
                        <th>Pertanyaan</th>
                      </tr>
                    </thead>
                    <tbody>
                  <tr>
    
    <td>ID</td>
    <td>
<select name="id">
<option value="">--</option>
<option value='1'>12</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>
<tr>
    <td>1.</td>    
    <td>Dosen mengajar sesuai dengan jadwal kuliah yang telah ditentukan</td>
    <td>
<select name='a1' id='a1'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>2.</td>    
    <td>Penyajian materi kuliah sistematis dan mudah dipahami</td>
    <td>
<select name='a2' id='a2'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>3.</td>    
    <td>Tujuan matakuliah diberikan dengan jelas</td>
    <td>
<select name='a3'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>4.</td>    
    <td>Materi perkuliahan yang disampaikan sesuai SAP</td>
    <td>
<select name='a4'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>5.</td>    
    <td>Dosen memberikan contoh yang jelas dan relevan dengan materi perkuliahan</td>
    <td>
<select name='a5'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>6.</td>    
    <td>Dosen memberikan kesempatan dan memotivasi mahasiswa untuk bertanya</td>
    <td>
<select name='a6'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>7.</td>    
    <td>Dosen memberikan jawaban dengan jelas pada pertanyaan mahasiswa</td>
    <td>
<select name='a7'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>8.</td>    
    <td>Dosen memberitahukan buku-buku referensi yang digunakan</td>
    <td>
<select name='a8'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>9.</td>    
    <td>Dosen memberikan motivasi kepada mahasiswa untuk membaca buku referensi&nbsp;</td>
    <td>
<select name='a9'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
</select>
    </td>
</tr>

<tr>
    <td>10.</td>    
    <td>Dosen berusaha memacu prestasi mahasiswa</td>
    <td>
<select name='a10'>
<option value=''>--</option>
<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>11.</td>    
    <td>Alat bantu yang digunakan relevan dengan kebutuhan</td>
    <td>
<select name="a11">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>1.</td>    
    <td>Dosen berbicara dengan jelas</td>
    <td>
<select name="b1">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>2.</td>    
    <td>Dosen selalu hadir tepat waktu</td>
    <td>
<select name="b2">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>3.</td>    
    <td>Dosen selalu mengikuti perkembangan baru dalam bidangnya</td>
    <td>
<select name="b3">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>4.</td>    
    <td>Dosen menjelaskan materi perkuliahan secara rinci / detail</td>
    <td>
<select name="b4">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>5.</td>    
    <td>Penjelasan materi perkuliahan mudah dipahami</td>
    <td>
<select name="b5">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>6.</td>    
    <td>Dosen terbuka terhadap masukan yang bersifat membangun</td>
    <td>
<select name="b6">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>7.</td>    
    <td>Dosen berpakaian dengan rapih dan sopan</td>
    <td>
<select name="b7">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>8.</td>    
    <td>Dosen bersedia membimbing mahasiswa didalam maupun diluar kelas&nbsp;</td>
    <td>
<select name="b8">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>9.</td>    
    <td>Dosen tidak sering menggantikan dan merubah jadwal kuliahnya</td>
    <td>
<select name="b9">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>1.</td>    
    <td>Dosen memberikan tugas</td>
    <td>
<select name="c1">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>2.</td>    
    <td>Hasil tugas dibahas kembali / diberi umpan balik</td>
    <td>
<select name="c2">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>3.</td>    
    <td>Tugas bermanfaat guna memperdalam materi kuliah&nbsp;</td>
    <td>
<select name="c3">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>4.</td>    
    <td>Soal ujian sesuai dengan materi kuliah</td>
    <td>
<select name="c4">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>
<tr>
    <td>1.</td>    
    <td>Buku-buku di perpustakaan menunjang proses belajar mengajar</td>
    <td>
<select name="d1">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>2.</td>    
    <td>Sarana yang tersedia di dalam ruang kelas cukup memadai</td>
    <td>
<select name="d2">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>3.</td>    
    <td>Laboratorium atau sarana penunjang mata kuliah terkait</td>
    <td>
<select name="d3">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>4.</td>    
    <td>Suasana belajar cukup menunjang dan kondusif</td>
    <td>
<select name="d4">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>5.</td>    
    <td>Fasilitas akses ke internet sangat membantu proses belajar-mengajar</td>
    <td>
<select name="d5">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

<tr>
    <td>6.</td>    
    <td>Hasil ujian segera diumumkan</td>
    <td>
<select name="d6">
<option value="">--</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
    </td>
</tr>

                    </tbody>
                  </table>
                  <input type="submit" name='submit' value='Simpan Semua Jawaban' class='pull-left btn btn-primary btn-sm'>
                </div><!-- /.box-body -->
              </form>
              </div><!-- /.box -->
            </div>
<?php } ?>