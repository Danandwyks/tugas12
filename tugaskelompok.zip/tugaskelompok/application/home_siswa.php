<?php if ($_GET[act]==''){ ?>
            <div class="col-xs-12">  
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title"><?php if (isset($_GET[tahun])){ echo "Daftar Dosen Pengajar"; }else{ echo "Daftar Dosen Pengajar Tahun ".date('Y'); } ?></h3>
                  <form style='margin-right:5px; margin-top:0px' class='pull-right' action='' method='GET'>
                    <select name='tahun' style='padding:4px'>
                        <?php 
                            echo "<option value=''>- Pilih Tahun Akademik -</option>";
                            $tahun = mysql_query("SELECT * FROM rb_tahun_akademik");
                            while ($k = mysql_fetch_array($tahun)){
                              if ($_GET[tahun]==$k[id_tahun_akademik]){
                                echo "<option value='$k[id_tahun_akademik]' selected>$k[nama_tahun]</option>";
                              }else{
                                echo "<option value='$k[id_tahun_akademik]'>$k[nama_tahun]</option>";
                              }
                            }
                        ?>
                    </select>
                    <input type="submit" style='margin-top:-4px' class='btn btn-success btn-sm' value='Lihat'>
                  </form>

                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th style='width:20px'>No</th>
                        <th>Nama Dosen</th>
                        <th>Mata Kuliah</th>
                        <th>Tahun Akademik</th>
                        <th>Status</th>
						   <th>sks</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                  <?php
                    if (isset($_GET[tahun])){
                      $tampil = mysql_query("SELECT * FROM nilaiakademik as a 
                                            JOIN evaluasidosen as b ON a.dosen=b.nama
                                              JOIN mahasiswa as c
                                                  where a.tahunakademik='$_GET[tahun]'");
                    
                    }else{
                      $tampil = mysql_query("SELECT *  FROM nilaiakademik  a 
                                            JOIN evaluasidosen  b ON a.dosen=b.nama
                                              JOIN mahasiswa  c
                                                  ");
                    }
                    $no = 1;
                    while($r=mysql_fetch_array($tampil)){
                    echo "<tr><td>$no</td>
                              <td>$r[dosen]</td>
                              <td>$r[namamk]</td>
                              <td>$r[tahunakademik]</td>
                              <td>$r[status]</td>
                              <td>$r[sks]</td>
                       
                              <td><a class='btn btn-success btn-xs' title='Lihat Data' href='index.php?view=home&act=kompetensidasar&kodejdwl=$r[kodejdwl]'><span class='glyphicon glyphicon-list'></span> Kompetensi</a></td>
                          </tr>";
                      $no++;
                      }
                  ?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
                </div>
            </div>

<?php 
}elseif ($_GET[act]=='kompetensidasar'){
    $d = mysql_fetch_array(mysql_query("SELECT * FROM nilaiakademik as a 
                                            JOIN evaluasidosen as b ON a.dosen=b.nama
                                              JOIN mahasiswa as c ON a.nim=c.nim  "));
            echo "<div class='col-xs-12'>  
              <div class='box'>
                <div class='box-header'>
                  <h3 class='box-title'>HASIL KERJA KELAS ANDA</h3>
                </div>
                <div class='box-body'>
                  <div class='col-md-12'>
                  <table class='table table-condensed table-hover'>
                      <tbody>
                        <input type='hidden' name='id' value='$d[kodemk]'>
                        <tr><th width='120px' scope='row'>Kode Kelas</th> <td>$d[kodemk]</td></tr>
                        <tr><th scope='row'>Nama Kelas</th>               <td>$d[namamk]</td></tr>
                       
                      </tbody>
                  </table>
                  </div>

                  <table class='table table-bordered table-striped'>
                    <thead>
                      <tr>
                        <th style='width:20px'>No</th>
                        <th>UTS</th>
                        <th>UAS</th>
                        <th>TUGAS</th>
                        <th>KUIS</th>
                      </tr>
                    </thead>
                    <tbody>";
                      $tampil = mysql_query("SELECT * FROM nilaiakademik as a 
                                            JOIN evaluasidosen as b ON a.tahunakademik=b.tahun
                                                ");
                    $no = 1;
                    while($r=mysql_fetch_array($tampil)){
                    echo "<tr><td>$no</td>
                              <td>$r[uts]</td>
                              <td>$r[uas]</td>
                              <td>$r[tugas]</td>
                              <td>$r[kuis]</td>
                          </tr>";
                      $no++;
                      }
                    echo "<tbody>
                  </table>
                </div>
                </div>
            </div>";
} 
?>